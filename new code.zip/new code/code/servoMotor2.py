from gpiozero import AngularServo
from time import sleep

# s = AngularServo(17, min_angle=-45, max_angle=45)
s = AngularServo(17,0,-90,90,0.0005,0.0025)

for t in range(0,91,15):
    s.angle = t
    sleep(1)

for t in range(90,-1,-15):
    s.angle = t
    sleep(1)

#move to minimum postion	
s.min()

for t in range(-90,91,30):
	s.angle = t
	sleep(1)
