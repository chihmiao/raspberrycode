from gpiozero import PWMLED
from time import sleep

led = PWMLED(17)

while True:
    for n in range(0,101,10):
        led.value = n / 100  # light
        sleep(1)
    
