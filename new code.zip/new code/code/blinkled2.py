from gpiozero import LED
from signal import pause

red = LED(17)

red.blink(.3,.3,10)

pause()